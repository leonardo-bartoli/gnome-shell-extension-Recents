# GNOME Shell Recent(item)s

Recent(item)s adds an indicator to gnome shell panel to quickly navigate recent open files.

### Features:

- purge all recent items stored by RecentManager
- ability to remove individual items
- search box

---

### Screenshot

![Screenshot](https://raw.githubusercontent.com/leonardo-bartoli/gnome-shell-extension-Recents/master/data/screenshot.png)
